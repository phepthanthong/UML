#include "Observer.h"
using namespace std;

void Observer::update(Observable o)
{}
