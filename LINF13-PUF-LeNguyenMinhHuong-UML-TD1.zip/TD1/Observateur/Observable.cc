#include "Observable.h"
using namespace std;

void Observable::addObserver(const Observer& ob) {
  
}

void Observable::deleteObserver(const Observer& ob) {

}

void Observable::serChanged() {

}

void Observable::notifyObservers(const Observer& ob) {

}
