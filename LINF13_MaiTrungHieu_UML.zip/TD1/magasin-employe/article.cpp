#include <iostream>
#include <string>
#include "article.h"
using namespace std;
Article::Article(int prix, string libelle){
  numArticle = nombreArticle;
  nombreArticle++;
  prixAchat = prix;
  libelleArticle = libelle;
}
