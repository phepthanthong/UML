#include "magasin.h"
#include <iostream>
#include <string>
using namespace std;
Magasin::Magasin(string nom, string adr){
nomMag = nom;
adrMag = adr;
}
